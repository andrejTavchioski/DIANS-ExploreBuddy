package com.example.explore_buddy.model.enumeration;

public enum LocationType {
    SPRING, LAKE, PEAK, LODGE, CAVE, WATERFALL
}
