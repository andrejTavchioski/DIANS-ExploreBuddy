package com.example.explore_buddy.config.email;

import com.example.explore_buddy.config.email.Mail;


public interface MailService {
    public void sendEmail(Mail mail);
}