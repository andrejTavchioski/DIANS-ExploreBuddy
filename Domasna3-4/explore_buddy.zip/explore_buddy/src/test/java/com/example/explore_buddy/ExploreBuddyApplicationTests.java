package com.example.explore_buddy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExploreBuddyApplicationTests {

    @Test
    void contextLoads() {
    }

}
